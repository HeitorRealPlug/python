numero = int(input('Digite um número:'))
print('O quadrado do número que o usuário digitou é:', numero**2)