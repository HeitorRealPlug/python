numero = int(input('Digite um número inteiro:'))
sucessor = numero +1
antecessor = numero -1
print('Seu sucessor e seu antecessor são respectivamente:', sucessor, 'e',antecessor)