base = int(input('Digite a medida da base do retângulo:'))
altura = int(input('Digite a medida da altura do retângulo:'))
area = base * altura
perimetro = 2 * base + 2 * altura
print('A área é', area, 'e o perímetro é', perimetro)