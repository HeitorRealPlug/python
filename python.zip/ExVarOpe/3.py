salario = float(input('Digite seu salário atual:'))
percentual = 10
novosalario = percentual /100 *salario
print(novosalario + salario)