catetoa = 4
catetob = 3
hipotenusa = catetoa**2 + catetob**2
print(hipotenusa)