pi = 3.1415
raio = float(input('Digite o raio:'))
altura = float(input('Digite a altura:'))
volume = pi * raio**2 * altura
print(volume)